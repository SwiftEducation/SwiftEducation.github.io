Teaching App Development with Swift
===================================

Course Materials Archive (June 22, 2015) from http://swifteducation.github.io.

---
Tip: Start with General Materials/CourseOverview.pdf and General Materials/LessonPlanOverview.pdf.
---

Join the community and contribute feedback:
http://github.com/swifteducation/teaching-app-dev-swift


LICENSE

This work is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License, by Yong Bakos.

https://creativecommons.org/licenses/by-nc-sa/4.0/
