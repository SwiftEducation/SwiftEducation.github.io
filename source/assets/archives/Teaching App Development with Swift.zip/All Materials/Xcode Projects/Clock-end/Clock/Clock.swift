/*

This work is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike
4.0 International License, by Yong Bakos.

*/

import Foundation

class Clock {
    
    var currentTime: NSDate {
        return NSDate()
    }
    
}