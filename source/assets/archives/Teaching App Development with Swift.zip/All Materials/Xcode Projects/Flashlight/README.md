# Flashlight

### Level 1, WordCollage Lesson 1

Build and run the "hello world" of iOS apps, to get students comfortable with opening a project and running it in the iOS Simulator.

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md)

## License

This work is licensed under a [Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License](https://creativecommons.org/licenses/by-nc-sa/4.0/), by Yong Bakos.
